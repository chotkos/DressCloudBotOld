﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using Awesomium.Core;

namespace Awesomium_in_WF
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            webControl1.Source = new Uri(textBox1.Text);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            webControl1.LoadingFrameComplete += new Awesomium.Core.FrameEventHandler(webControl1_LoadingFrameComplete);
            webControl1.Source = new Uri(textBox1.Text);
        }

        private void webControl1_LoadingFrameComplete(object sender, Awesomium.Core.FrameEventArgs e)
        {
            if (webControl1.IsLoading || !webControl1.IsLive)
                return;

            // really all DOM loaded
            MessageBox.Show(webControl1.Title);
            webControl1.LoadingFrameComplete -= new Awesomium.Core.FrameEventHandler(webControl1_LoadingFrameComplete);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            webControl1.LoadHTML("<html><head><script>alert('Hello, world');</script></head><body><b>Hello, World!</b></body></html>");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            webControl1.ExecuteJavascript("document.body.innerHTML += '<i>Hello, World!</i>';");
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Awesomium.Core.WebCore.Shutdown();
        }

        private void button5_Click(object cender, EventArgs e)
        {
            webControl1.Dispose();
            var ws = WebCore.CreateWebSession(new WebPreferences() { Javascript = false });
            webControl1 = new Awesomium.Windows.Forms.WebControl() { WebSession = ws };
            webControl1.Location = new Point(12, 160);
            webControl1.Size = new Size(613, 297);
            this.Controls.Add(webControl1);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            webControl1.Dispose();
            var ws = WebCore.CreateWebSession(new WebPreferences() { Javascript = true });
            webControl1 = new Awesomium.Windows.Forms.WebControl() { WebSession = ws };
            webControl1.Location = new Point(12, 160);
            webControl1.Size = new Size(613, 297);
            this.Controls.Add(webControl1);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            System.IO.File.WriteAllText("HTML.html", webControl1.ExecuteJavascriptWithResult("document.documentElement.outerHTML"));
            MessageBox.Show("Code saved to HTML.html file.");
        }
    }
}
